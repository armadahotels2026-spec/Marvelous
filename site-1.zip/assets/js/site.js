/* Marvelous Hotel — progressive enhancement. Every page works without JavaScript; this file adds
   dropdown navigation, the mobile drawer, language memory, scroll states, reveal motion, gallery
   filtering + lightbox, accordions, tabs, scroll-spy sub-navigation, form validation with an
   e-mail / WhatsApp hand-off (or a POST when an endpoint is configured), query-string prefill and
   a cross-page fade where the View Transitions API is absent. Features are isolated from each other. */
(function () {
  'use strict';
  var d = document, html = d.documentElement, body = d.body;
  var lang = body.dataset.lang || 'en', rtl = html.dir === 'rtl';
  var reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  var $ = function (s, r) { return (r || d).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || d).querySelectorAll(s)); };
  var run = function (name, fn) { try { fn(); } catch (e) { if (window.console) console.warn('site.js: ' + name + ' skipped —', e); } };
  var I18N = {}; try { I18N = JSON.parse($('#i18n-js').textContent); } catch (e) {}
  var t = function (k, vars) { var s = I18N[k] || k; Object.keys(vars || {}).forEach(function (v) { s = s.replace('{' + v + '}', vars[v]); }); return s; };
  html.classList.add('js-ready');
  run('top', function () {   /* a freshly navigated page always starts at its top (some embedded viewers carry the previous scroll position over) */
    var nav = (performance.getEntriesByType && performance.getEntriesByType('navigation')[0]) || null; var fresh = !nav || nav.type === 'navigate';
    var reset = function () { if (!location.hash && fresh && (window.pageYOffset || 0) > 0) window.scrollTo({ top: 0, behavior: 'instant' }); };
    reset(); window.addEventListener('load', reset); window.addEventListener('pageshow', function (e) { if (!e.persisted) reset(); });
  });
  setTimeout(function () { $$('.reveal').forEach(function (el) { el.classList.add('is-visible'); }); }, 2500);

  run('language', function () {
    try { localStorage.setItem('mh-lang', lang); } catch (e) {}
    $$('[data-set-lang]').forEach(function (a) { a.addEventListener('click', function () { try { localStorage.setItem('mh-lang', a.dataset.setLang); } catch (e) {} }); });
  });

  run('scroll', function () {
    var header = $('.site-header'), top = $('.to-top'), ticking = false;
    var onScroll = function () { if (ticking) return; ticking = true; requestAnimationFrame(function () { var y = window.pageYOffset || 0; header && header.classList.toggle('is-scrolled', y > 10); top && top.classList.toggle('is-visible', y > 800); ticking = false; }); };
    window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
    top && top.addEventListener('click', function (e) { e.preventDefault(); window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' }); var m = $('#content'); if (m) { try { m.focus({ preventScroll: true }); } catch (x) {} } });
  });

  run('dropdowns', function () {
    var items = $$('.nav__item--drop');
    var closeAll = function (except) { items.forEach(function (it) { if (it !== except) { $('.nav__link', it).setAttribute('aria-expanded', 'false'); $('.drop', it).classList.remove('is-open'); } }); };
    items.forEach(function (it) {
      var btn = $('.nav__link', it), menu = $('.drop', it), timer;
      var open = function () { closeAll(it); btn.setAttribute('aria-expanded', 'true'); menu.classList.add('is-open'); };
      var close = function () { btn.setAttribute('aria-expanded', 'false'); menu.classList.remove('is-open'); };
      btn.addEventListener('click', function (e) { e.preventDefault(); btn.getAttribute('aria-expanded') === 'true' ? close() : open(); });
      it.addEventListener('mouseenter', function () { clearTimeout(timer); timer = setTimeout(open, 80); });
      it.addEventListener('mouseleave', function () { clearTimeout(timer); timer = setTimeout(close, 180); });
      it.addEventListener('focusout', function (e) { if (!it.contains(e.relatedTarget)) close(); });
      it.addEventListener('keydown', function (e) { if (e.key === 'Escape') { close(); btn.focus(); } if (e.key === 'ArrowDown' && btn.getAttribute('aria-expanded') === 'true') { e.preventDefault(); var f = $('a', menu); f && f.focus(); } });
    });
    d.addEventListener('click', function (e) { if (!e.target.closest('.nav__item--drop')) closeAll(); });
  });

  run('drawer', function () {
    var toggle = $('.nav-toggle'), drawer = $('#drawer'); if (!toggle || !drawer) return;
    var set = function (open) { toggle.setAttribute('aria-expanded', open ? 'true' : 'false'); toggle.setAttribute('aria-label', open ? toggle.dataset.labelClose : toggle.dataset.labelOpen); open ? drawer.setAttribute('data-open', 'true') : drawer.removeAttribute('data-open'); body.classList.toggle('nav-open', open); if (open) { var f = $('a, button', drawer); f && f.focus({ preventScroll: true }); } };
    var isOpen = function () { return drawer.getAttribute('data-open') === 'true'; };
    toggle.addEventListener('click', function () { set(!isOpen()); });
    drawer.addEventListener('click', function (e) { if (e.target.closest('a') && isOpen()) set(false); });
    d.addEventListener('keydown', function (e) { if (e.key === 'Escape' && isOpen()) { set(false); toggle.focus(); } });
    var mq = window.matchMedia('(min-width: 1001px)'); var onChange = function () { if (mq.matches && isOpen()) set(false); };
    mq.addEventListener ? mq.addEventListener('change', onChange) : mq.addListener(onChange);
  });

  run('reveal', function () {
    var els = $$('.reveal'); if (!els.length) return;
    if (reduce || !('IntersectionObserver' in window)) { els.forEach(function (el) { el.classList.add('is-visible'); }); return; }
    var io = new IntersectionObserver(function (entries) { entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('is-visible'); io.unobserve(en.target); } }); }, { rootMargin: '0px 0px -8% 0px', threshold: .06 });
    els.forEach(function (el) { io.observe(el); });
  });

  /* gallery category filter (buttons filter the grid; the count updates; URL hash remembers the category) */
  run('gallery filter', function () {
    var root = $('[data-gallery]'); if (!root) return;
    var btns = $$('[data-cat]'), items = $$('[data-item-cat]', root), count = $('[data-gallery-count]');
    var apply = function (cat) {
      btns.forEach(function (b) { b.classList.toggle('is-active', b.dataset.cat === cat); b.setAttribute('aria-pressed', b.dataset.cat === cat ? 'true' : 'false'); });
      var n = 0; items.forEach(function (it) { var ok = cat === 'all' || it.dataset.itemCat === cat; it.hidden = !ok; if (ok) n++; });
      if (count) count.textContent = t('count', { n: n });
      try { history.replaceState(null, '', cat === 'all' ? location.pathname : '#' + cat); } catch (e) {}
    };
    btns.forEach(function (b) { b.addEventListener('click', function () { apply(b.dataset.cat); }); });
    var h = (location.hash || '').slice(1); apply(btns.some(function (b) { return b.dataset.cat === h; }) ? h : 'all');
  });

  run('lightbox', function () {
    var items = $$('[data-lightbox]'); if (!items.length) return;
    var lb = d.createElement('div'); lb.className = 'lightbox'; lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true'); lb.setAttribute('aria-label', t('gallery'));
    lb.innerHTML = '<button class="lightbox__btn lightbox__close" type="button" aria-label="' + t('close') + '"><svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6L6 18"/></svg></button>' +
      '<button class="lightbox__btn lightbox__prev" type="button" aria-label="' + t('prev') + '"><svg class="i i--dir" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 6l-6 6 6 6"/></svg></button>' +
      '<img alt=""><button class="lightbox__btn lightbox__next" type="button" aria-label="' + t('next') + '"><svg class="i i--dir" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></button><div class="lightbox__cap"></div>';
    body.appendChild(lb);
    var img = $('img', lb), cap = $('.lightbox__cap', lb), cur = 0, last;
    var visible = function () { return items.filter(function (a) { return !a.closest('[hidden]'); }); };
    var show = function (i) { var v = visible(); cur = (i + v.length) % v.length; var a = v[cur]; img.style.opacity = 0; img.onload = function () { img.style.opacity = 1; }; img.src = a.getAttribute('href'); img.alt = a.dataset.caption || ''; cap.textContent = (a.dataset.caption || '') + '  ·  ' + (cur + 1) + ' ' + t('of') + ' ' + v.length; };
    var open = function (a) { last = d.activeElement; show(visible().indexOf(a)); lb.classList.add('is-open'); body.style.overflow = 'hidden'; $('.lightbox__close', lb).focus(); };
    var close = function () { lb.classList.remove('is-open'); body.style.overflow = ''; last && last.focus(); };
    items.forEach(function (a) { a.addEventListener('click', function (e) { e.preventDefault(); open(a); }); });
    $('.lightbox__close', lb).addEventListener('click', close); $('.lightbox__prev', lb).addEventListener('click', function () { show(cur - 1); }); $('.lightbox__next', lb).addEventListener('click', function () { show(cur + 1); });
    lb.addEventListener('click', function (e) { if (e.target === lb) close(); });
    d.addEventListener('keydown', function (e) { if (!lb.classList.contains('is-open')) return; if (e.key === 'Escape') close(); if (e.key === (rtl ? 'ArrowLeft' : 'ArrowRight')) show(cur + 1); if (e.key === (rtl ? 'ArrowRight' : 'ArrowLeft')) show(cur - 1); });
    var sx = 0; lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
    lb.addEventListener('touchend', function (e) { var dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 40) show(cur + ((dx < 0) !== rtl ? 1 : -1)); });
  });

  run('accordion', function () {
    $$('.acc__btn').forEach(function (btn) { var panel = d.getElementById(btn.getAttribute('aria-controls')); btn.addEventListener('click', function () { var open = btn.getAttribute('aria-expanded') === 'true'; btn.setAttribute('aria-expanded', open ? 'false' : 'true'); panel.hidden = open; }); });
  });

  run('tabs', function () {
    $$('[data-tabs]').forEach(function (root) {
      var tabs = $$('[role="tab"]', root), panels = $$('[role="tabpanel"]', root);
      var select = function (i, focus) { tabs.forEach(function (tb, j) { var on = i === j; tb.setAttribute('aria-selected', on ? 'true' : 'false'); tb.tabIndex = on ? 0 : -1; panels[j].hidden = !on; if (on && focus) tb.focus(); }); };
      tabs.forEach(function (tb, i) { tb.addEventListener('click', function () { select(i); }); tb.addEventListener('keydown', function (e) { var n = tabs.length, next = rtl ? 'ArrowLeft' : 'ArrowRight', prev = rtl ? 'ArrowRight' : 'ArrowLeft'; if (e.key === next) select((i + 1) % n, true); else if (e.key === prev) select((i - 1 + n) % n, true); else return; e.preventDefault(); }); });
      select(0);
    });
  });

  run('subnav', function () {
    var links = $$('.subnav a[href^="#"], .z-bar__nav a[href^="#"]'); if (!links.length || !('IntersectionObserver' in window)) return;
    var map = {}; links.forEach(function (a) { var s = $(a.getAttribute('href')); if (s) map[s.id] = a; });
    var io = new IntersectionObserver(function (entries) { entries.forEach(function (en) { if (en.isIntersecting) { links.forEach(function (a) { a.classList.remove('is-active'); }); map[en.target.id].classList.add('is-active'); } }); }, { rootMargin: '-30% 0px -60% 0px' });
    Object.keys(map).forEach(function (id) { io.observe(d.getElementById(id)); });
  });

  run('forms', function () {
    $$('form[data-enquiry]').forEach(function (form) {
      form.setAttribute('novalidate', '');
      var summary = $('.form__summary', form), result = $('.form__result', form.parentNode) || $('.form__result'), submit = $('[type="submit"]', form);
      var check = function (el) {
        var f = el.closest('.field'); if (!f) return true;
        var v = (el.value || '').trim(), ok = true, msg = '';
        if (el.required && !v) { ok = false; msg = el.tagName === 'SELECT' ? t('f_select') : t('f_required'); }
        else if (v && el.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) { ok = false; msg = t('f_email'); }
        else if (v && el.type === 'tel' && !/^\+?[0-9 ()-]{7,20}$/.test(v)) { ok = false; msg = t('f_phone'); }
        else if (v && el.type === 'date') { var dt = new Date(v + 'T00:00:00'), today = new Date(); today.setHours(0, 0, 0, 0); if (isNaN(dt) || dt < today) { ok = false; msg = t('f_date'); } }
        else if (v && el.type === 'number' && Number(v) < Number(el.min || 1)) { ok = false; msg = t('f_number'); }
        else if (v && el.id === 'checkout' && form.querySelector('#checkin') && form.querySelector('#checkin').value && v <= form.querySelector('#checkin').value) { ok = false; msg = t('f_date'); }
        f.classList.toggle('is-invalid', !ok); el.setAttribute('aria-invalid', ok ? 'false' : 'true'); var err = $('.field__err', f); if (err) err.textContent = msg; return ok;
      };
      $$('input, select, textarea', form).forEach(function (el) { el.addEventListener('blur', function () { check(el); }); el.addEventListener('input', function () { if (el.closest('.field').classList.contains('is-invalid')) check(el); }); });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var bad = $$('input, select, textarea', form).filter(function (el) { return !check(el); });
        if (bad.length) { summary.textContent = t('f_summary'); summary.classList.add('is-visible'); bad[0].focus(); return; }
        summary.classList.remove('is-visible');
        var data = {}, lines = [];
        $$('input, select, textarea', form).forEach(function (el) { if (!el.name || el.type === 'submit') return; var label = $('label[for="' + el.id + '"]', form); var lv = label ? label.textContent.replace('*', '').replace(/\(.*\)/, '').trim() : el.name; var val = el.tagName === 'SELECT' ? (el.options[el.selectedIndex] ? el.options[el.selectedIndex].text : '') : el.value; data[el.name] = val; if (val) lines.push(lv + ': ' + val); });
        var subject = form.dataset.subject || d.title, text = subject + '\n\n' + lines.join('\n');
        var endpoint = form.dataset.endpoint, mail = form.dataset.mail, wa = form.dataset.wa;
        var show = function (cls, title, bodyText, actions) { result.className = 'form__result is-visible ' + cls; result.innerHTML = '<h3 tabindex="-1">' + title + '</h3><p>' + bodyText + '</p>' + (actions || ''); result.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'center' }); $('h3', result).focus(); };
        if (endpoint) {
          submit.disabled = true; var old = submit.textContent; submit.textContent = t('sending');
          fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }, body: JSON.stringify({ subject: subject, page: location.href, lang: lang, fields: data }) })
            .then(function (r) { if (!r.ok) throw new Error(r.status); show('is-ok', t('posted_title'), t('posted_text')); form.reset(); })
            .catch(function () { show('is-err', t('error_title'), t('error_text')); })
            .then(function () { submit.disabled = false; submit.textContent = old; });
          return;
        }
        var mailto = 'mailto:' + mail + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(text);
        var waBtn = wa ? '<a class="btn' + (form.dataset.primary === 'wa' ? '' : ' btn--outline') + '" target="_blank" rel="noopener" href="https://wa.me/' + wa + '?text=' + encodeURIComponent(text) + '">' + t('send_wa') + '</a>' : '';
        var mailBtn = '<a class="btn' + (form.dataset.primary === 'wa' ? ' btn--outline' : '') + '" href="' + mailto + '">' + t('send_email') + '</a>';
        var actions = '<div class="form__actions">' + (form.dataset.primary === 'wa' ? waBtn + mailBtn : mailBtn + waBtn) + '</div>';
        show('is-ok', t('success_title'), t('success_text', { wa: wa ? t('success_wa') : '' }), actions);
      });
    });
    try { var qs = new URLSearchParams(location.search); ['service', 'vehicle', 'subject', 'room'].forEach(function (k) { var v = qs.get(k), el = d.getElementById(k); if (v && el && el.tagName === 'SELECT' && $$('option', el).some(function (o) { return o.value === v; })) el.value = v; }); } catch (e) {}
    try { var qs2 = new URLSearchParams(location.search); ['checkin', 'checkout', 'adults', 'children', 'rooms'].forEach(function (k) { var v = qs2.get(k), el = d.getElementById(k); if (v && el && el.tagName === 'INPUT') { el.value = v; el.dispatchEvent(new Event('change')); } }); } catch (e) {}
    var today = new Date(); var iso = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
    $$('input[type="date"]').forEach(function (el) { el.min = iso; });
  });

  run('slider', function () {   /* hero crossfade slider (hotel home + Zimam) — arrows, dots, keyboard, autoplay (paused on hover/focus, off with reduced motion) */
    $$('[data-slider]').forEach(function (root) {
      var slides = $$('[data-slide]', root), dots = $('[data-slider-dots]', root), cap = $('[data-slider-caption] b', root); if (slides.length < 2) { if (dots) dots.hidden = true; $$('[data-slider-prev], [data-slider-next]', root).forEach(function (b) { b.hidden = true; }); return; }
      var i = 0, timer, btns = [];
      slides.forEach(function (s, j) { var b = d.createElement('button'); b.type = 'button'; b.setAttribute('role', 'tab'); b.setAttribute('aria-label', (s.dataset.caption || (j + 1))); b.addEventListener('click', function () { go(j); restart(); }); dots.appendChild(b); btns.push(b); });
      var bgs = $$('[data-slide-bg]', root);
      var go = function (n) { i = (n + slides.length) % slides.length; slides.forEach(function (s, j) { s.classList.toggle('is-active', j === i); }); bgs.forEach(function (s, j) { s.classList.toggle('is-active', j === i); }); btns.forEach(function (b, j) { b.classList.toggle('is-active', j === i); b.setAttribute('aria-selected', j === i ? 'true' : 'false'); }); if (cap) cap.textContent = slides[i].dataset.caption || ''; };
      var restart = function () { clearTimeout(timer); if (reduce) return; timer = setTimeout(function () { go(i + 1); restart(); }, 6000); };
      $('[data-slider-prev]', root).addEventListener('click', function () { go(i - 1); restart(); });
      $('[data-slider-next]', root).addEventListener('click', function () { go(i + 1); restart(); });
      root.addEventListener('keydown', function (e) { var next = rtl ? 'ArrowLeft' : 'ArrowRight', prev = rtl ? 'ArrowRight' : 'ArrowLeft'; if (e.key === next) { go(i + 1); restart(); } else if (e.key === prev) { go(i - 1); restart(); } });
      root.addEventListener('mouseenter', function () { clearTimeout(timer); }); root.addEventListener('mouseleave', restart);
      root.addEventListener('focusin', function () { clearTimeout(timer); }); root.addEventListener('focusout', restart);
      var x0 = null; root.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true }); root.addEventListener('touchend', function (e) { if (x0 === null) return; var dx = e.changedTouches[0].clientX - x0; x0 = null; if (Math.abs(dx) < 40) return; go(i + ((dx < 0) !== rtl ? 1 : -1)); restart(); }, { passive: true });
      d.addEventListener('visibilitychange', function () { if (d.hidden) clearTimeout(timer); else restart(); });
      go(0); restart();
    });
  });

  run('images', function () {   /* blur-up: the tiny placeholder stays until the real image has decoded */
    var hydrate = function (img) { var pic = img.closest('picture'); $$('source[data-srcset]', pic).forEach(function (so) { so.srcset = so.dataset.srcset; so.removeAttribute('data-srcset'); }); if (img.dataset.srcset) { img.srcset = img.dataset.srcset; img.removeAttribute('data-srcset'); } if (img.dataset.src) { img.src = img.dataset.src; img.removeAttribute('data-src'); } img.classList.remove('is-deferred'); };
    var deferred = $$('img.is-deferred'); if (deferred.length) { var go = function () { deferred.forEach(hydrate); }; if (d.readyState === 'complete') setTimeout(go, 800); else window.addEventListener('load', function () { setTimeout(go, 800); }); }
    $$('.pic--lqip img').forEach(function (img) { var done = function () { img.classList.add('is-loaded'); }; if (img.complete && img.naturalWidth) done(); else { img.addEventListener('load', done); img.addEventListener('error', done); } });
  });

  run('search', function () {   /* reservation search strip → the Book page with the dates and guests pre-filled (GET form works without JS; this adds validation) */
    $$('form[data-search]').forEach(function (form) {
      form.setAttribute('novalidate', '');
      var ci = $('[name="checkin"]', form), co = $('[name="checkout"]', form);
      var iso = function (dt) { return dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0'); };
      var today = new Date(); today.setHours(0, 0, 0, 0); ci.min = iso(today);
      var tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1); co.min = iso(tomorrow);
      ci.addEventListener('change', function () { if (!ci.value) return; var n = new Date(ci.value + 'T00:00:00'); n.setDate(n.getDate() + 1); co.min = iso(n); if (!co.value || co.value <= ci.value) co.value = iso(n); });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var ok = ci.value && co.value && ci.value >= iso(today) && co.value > ci.value;
        form.classList.toggle('is-invalid', !ok); if (!ok) { (ci.value ? co : ci).focus(); return; }
        var q = new URLSearchParams(); $$('input, select', form).forEach(function (el) { if (el.name && el.value) q.set(el.name, el.value); });
        location.href = form.getAttribute('action') + '?' + q.toString() + '#request';
      });
    });
  });

  run('transitions', function () {   /* cross-document View Transitions do the work where supported (CSS); this adds the shared room image + a fade fallback. External links are never delayed. */
    var vt = ('startViewTransition' in d);
    d.addEventListener('click', function (e) {
      var a = e.target.closest('a[href]'); if (!a || a.target === '_blank' || a.hasAttribute('download') || e.metaKey || e.ctrlKey || e.shiftKey || e.button) return;
      var url = new URL(a.href, location.href); if (url.origin !== location.origin || url.pathname === location.pathname) return;
      if (a.dataset.vt) { $$('[data-vt] img').forEach(function (im) { im.style.viewTransitionName = ''; }); var im = $('img', a); if (im) im.style.viewTransitionName = a.dataset.vt; }
      if (reduce || vt) return;
      e.preventDefault(); html.classList.add('is-leaving'); setTimeout(function () { location.href = a.href; }, 190);
    });
    window.addEventListener('pageshow', function () { html.classList.remove('is-leaving'); $$('[data-vt] img').forEach(function (im) { im.style.viewTransitionName = ''; }); });
  });

  /* ---- premium 3D layer (Oct 2026): everything below is decorative, pointer-gated and off under reduced motion ---- */
  var fine = !!(window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches);
  if (!fine) html.classList.add('is-touch');

  run('stagger', function () {   /* children of [data-stagger] enter one after another — no per-element delay classes needed */
    $$('[data-stagger]').forEach(function (root) { $$('.reveal', root).forEach(function (el, i) { if (!el.style.transitionDelay) el.style.transitionDelay = Math.min(i, 9) * 80 + 'ms'; }); });
  });

  run('tilt', function () {   /* .card3d[data-tilt]: perspective tilt + glare + image drift from the pointer; fine pointers only */
    if (!fine || reduce) return;
    $$('[data-tilt]').forEach(function (el) {
      var max = parseFloat(el.dataset.tiltMax || 6), raf = 0, px = 0, py = 0;
      var paint = function () { raf = 0; var r = el.getBoundingClientRect(); if (!r.width) return; var x = (px - r.left) / r.width, y = (py - r.top) / r.height; x = Math.min(1, Math.max(0, x)); y = Math.min(1, Math.max(0, y));
        el.style.setProperty('--ry', ((x - .5) * 2 * max).toFixed(2) + 'deg'); el.style.setProperty('--rx', ((.5 - y) * 2 * max).toFixed(2) + 'deg');
        el.style.setProperty('--px', (x * 100).toFixed(1) + '%'); el.style.setProperty('--py', (y * 100).toFixed(1) + '%');
        el.style.setProperty('--ix', ((.5 - x) * 2.4).toFixed(2) + '%'); el.style.setProperty('--iy', ((.5 - y) * 2.4).toFixed(2) + '%'); };
      el.addEventListener('pointerenter', function () { el.classList.add('is-tilting'); });
      el.addEventListener('pointermove', function (e) { px = e.clientX; py = e.clientY; if (!raf) raf = requestAnimationFrame(paint); });
      el.addEventListener('pointerleave', function () { if (raf) cancelAnimationFrame(raf); raf = 0; el.classList.remove('is-tilting'); ['--rx', '--ry', '--ix', '--iy'].forEach(function (k) { el.style.removeProperty(k); }); });
    });
  });

  run('scene', function () {   /* hero depth: each .hero__layer drifts with the pointer at its own rate (data-depth); scroll parallax stays in CSS */
    var scene = $('[data-scene]'); if (!scene || !fine || reduce) return;
    var layers = $$('.hero__layer', scene).map(function (el) { return { el: el, d: parseFloat(el.dataset.depth || 1) }; }), raf = 0, mx = 0, my = 0;
    var paint = function () { raf = 0; layers.forEach(function (l) { l.el.style.translate = (mx * l.d * 16).toFixed(1) + 'px ' + (my * l.d * 11).toFixed(1) + 'px'; }); };
    scene.addEventListener('pointermove', function (e) { var r = scene.getBoundingClientRect(); mx = (e.clientX - r.left) / r.width - .5; my = (e.clientY - r.top) / r.height - .5; if (!raf) raf = requestAnimationFrame(paint); });
    scene.addEventListener('pointerleave', function () { mx = my = 0; if (!raf) raf = requestAnimationFrame(paint); });
  });

  run('magnetic', function () {   /* [data-magnetic] buttons lean a few pixels towards the pointer and spring back — never further than 6 px */
    if (!fine || reduce) return;
    $$('[data-magnetic]').forEach(function (b) {
      var raf = 0, x = 0, y = 0;
      var paint = function () { raf = 0; b.style.transform = 'translate(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px)'; };
      b.addEventListener('pointerenter', function () { b.classList.add('is-magnet'); });
      b.addEventListener('pointermove', function (e) { var r = b.getBoundingClientRect(); x = Math.max(-6, Math.min(6, (e.clientX - (r.left + r.width / 2)) * .18)); y = Math.max(-6, Math.min(6, (e.clientY - (r.top + r.height / 2)) * .18)); if (!raf) raf = requestAnimationFrame(paint); });
      b.addEventListener('pointerleave', function () { b.classList.remove('is-magnet'); x = y = 0; if (!raf) raf = requestAnimationFrame(paint); setTimeout(function () { if (!x && !y) b.style.transform = ''; }, 520); });
    });
  });

  run('count', function () {   /* verified numerals count up once when they scroll into view */
    var els = $$('[data-count]'); if (!els.length || reduce || !('IntersectionObserver' in window)) return;
    var io = new IntersectionObserver(function (entries) { entries.forEach(function (en) { if (!en.isIntersecting) return; io.unobserve(en.target); var el = en.target, to = parseInt(el.dataset.count, 10), t0 = null;
      var step = function (ts) { if (!t0) t0 = ts; var p = Math.min(1, (ts - t0) / 1100), e = 1 - Math.pow(1 - p, 3); el.textContent = Math.round(to * e); if (p < 1) requestAnimationFrame(step); else el.textContent = to; }; requestAnimationFrame(step); }); }, { threshold: .4 });
    els.forEach(function (el) { io.observe(el); });
  });

  run('map', function () {   /* the Google map is a third-party frame loaded on request; the distance diagram stays until it arrives */
    $$('[data-map-src]').forEach(function (map) {
      var btn = $('.map__load', map), src = map.dataset.mapSrc; if (!btn || !src) return;
      btn.addEventListener('click', function () {
        map.classList.add('is-loading'); btn.textContent = btn.dataset.loading || btn.textContent;
        var f = d.createElement('iframe'); f.src = src; f.title = map.dataset.mapTitle || ''; f.loading = 'eager'; f.referrerPolicy = 'no-referrer-when-downgrade'; f.allowFullscreen = true;
        f.addEventListener('load', function () { map.classList.remove('is-loading'); map.classList.add('is-live'); });
        map.insertBefore(f, map.firstChild);
      });
    });
  });

  run('social', function () {   /* pending social icons: a click shows the approval note near the icon (no dead links) */
    var btns = $$('[data-social-pending]'); if (!btns.length) return;
    var tip = d.createElement('div'); tip.className = 'social-tip'; tip.setAttribute('role', 'status'); body.appendChild(tip); var timer;
    btns.forEach(function (b) { b.addEventListener('click', function () { var r = b.getBoundingClientRect(); tip.textContent = b.dataset.socialPending; tip.style.top = (r.top - 10) + 'px'; tip.style.left = Math.max(8, Math.min(window.innerWidth - 8 - 300, r.left + r.width / 2 - 150)) + 'px'; tip.style.transform = 'translateY(-100%)'; tip.classList.add('is-in'); clearTimeout(timer); timer = setTimeout(function () { tip.classList.remove('is-in'); }, 3200); }); });
    d.addEventListener('click', function (e) { if (!e.target.closest('[data-social-pending]')) tip.classList.remove('is-in'); });
  });

  run('route', function () { if (reduce) $$('.logi__route animateMotion').forEach(function (a) { a.parentNode.removeChild(a); }); });
})();


/* Marvel — the animated welcome assistant of Marvelous Hotel (Oct 2026).
   Predefined responses only: a bilingual dictionary (content/i18n → #marvel-js) and keyword intent matching.
   No AI API, no backend, no storage beyond sessionStorage (the visitor's optional first name, the sound preference),
   no external audio: the voice uses the browser's Web Speech API when present, the optional chime is a 2-note WebAudio tone.
   Typing indicator → progressive reveal → action buttons; one queue so rapid clicks never overlap; everything is
   cancelled when the panel closes; reduced motion shows messages at once; all controls are keyboard-operable. */
(function () {
  'use strict';
  var d = document, html = d.documentElement, body = d.body;
  var cfgEl = d.getElementById('marvel-js'); if (!cfgEl) return;
  var M; try { M = JSON.parse(cfgEl.textContent); } catch (e) { return; }
  var T = M.t, L = M.links, lang = M.lang || 'en', rtl = html.dir === 'rtl';
  var reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  var store = { get: function (k) { try { return sessionStorage.getItem(k) || ''; } catch (e) { return ''; } }, set: function (k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} } };
  var el = function (tag, cls, text) { var n = d.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  var ICON = {
    mark: '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M12 40V22a12 12 0 0 1 24 0v18" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/><path d="M19 29.5c1.6 2 3.3 3 5 3s3.4-1 5-3" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/><circle cx="19.5" cy="23" r="1.9" fill="currentColor"/><circle cx="28.5" cy="23" r="1.9" fill="currentColor"/><path d="M36 8l1.2 3 3 1.2-3 1.2L36 16.4l-1.2-3-3-1.2 3-1.2z" fill="currentColor"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    speak: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 10v4h4l5 4V6L8 10H4z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/></svg>',
    stop: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="1.5"/></svg>',
    bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4l2-2z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>',
    bellOff: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4l2-2z"/><path d="M10 20a2 2 0 0 0 4 0M4 4l16 16"/></svg>',
    send: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
    ext: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/></svg>'
  };

  /* ---- intents: keyword lists per language (Arabic normalised: diacritics removed, alef/yaa/taa-marbuta unified) ---- */
  var norm = function (s) { return (s || '').toLowerCase().replace(/[ً-ْـ]/g, '').replace(/[إأآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/\s+/g, ' ').trim(); };
  var INTENTS = [
    ['bye', ['bye', 'goodbye', 'see you', 'later', 'مع السلامه', 'الى اللقاء', 'باي', 'سلام', 'وداعا', 'في امان الله']],
    ['thanks', ['thank', 'thx', 'شكرا', 'مشكور', 'يعطيك العافيه', 'تسلم', 'ممنون']],
    ['greeting', ['hello', 'hi', 'hey', 'good morning', 'good evening', 'salam', 'مرحبا', 'اهلا', 'هلا', 'السلام', 'صباح', 'مساء', 'هاي']],
    ['transport', ['transport', 'transfer', 'car', 'bus', 'taxi', 'driver', 'chauffeur', 'airport', 'zimam', 'logistic', 'shuttle', 'pickup', 'pick-up', 'نقل', 'توصيل', 'سياره', 'باص', 'حافله', 'سائق', 'مطار', 'زمام', 'لوجست', 'مواصلات', 'تاكسي']],
    ['book', ['book', 'reserv', 'availab', 'rate', 'price', 'room for', 'check in', 'check-in', 'checkin', 'حجز', 'احجز', 'سعر', 'اسعار', 'توفر', 'متاح', 'ليله']],
    ['contact', ['contact', 'call', 'phone', 'email', 'e-mail', 'whatsapp', 'number', 'reach', 'talk', 'تواصل', 'اتصال', 'اتصل', 'رقم', 'هاتف', 'جوال', 'بريد', 'ايميل', 'واتساب', 'واتس']],
    ['faq', ['faq', 'question', 'policy', 'policies', 'check out', 'checkout', 'check-out', 'time', 'hours', 'pet', 'smok', 'child', 'deposit', 'cancel', 'اسئله', 'سؤال', 'سياس', 'مغادره', 'وصول', 'وقت', 'مواعيد', 'ساعات', 'اطفال', 'تدخين', 'الغاء', 'تامين']],
    ['services', ['service', 'facilit', 'amenit', 'restaurant', 'dining', 'breakfast', 'food', 'gym', 'fitness', 'meeting', 'parking', 'wifi', 'wi-fi', 'laundry', 'gallery', 'photo', 'room', 'suite', 'خدم', 'مرافق', 'مطعم', 'طعام', 'فطور', 'بوفيه', 'جيم', 'رياض', 'اجتماع', 'مواقف', 'واي فاي', 'غسيل', 'معرض', 'صور', 'غرف', 'غرفه', 'جناح', 'اجنحه']],
    ['about', ['about', 'who', 'what is', 'marvelous', 'hotel', 'where', 'location', 'address', 'tabuk', 'map', 'عن', 'من انتم', 'ما هو', 'مارفوليس', 'مارفيليوس', 'فندق', 'وين', 'اين', 'موقع', 'عنوان', 'تبوك', 'خريطه']],
    ['meetings', ['meeting', 'conference', 'coffee break', 'coffee-break', 'seminar', 'workshop', 'event', 'اجتماع', 'قاعه', 'كوفي', 'بريك', 'مؤتمر', 'ورشه', 'فعاليه', 'مناسبه']],
    ['catering', ['catering', 'cater', 'outside order', 'delivery', 'buffet for', 'banquet', 'اعاشه', 'تموين', 'طلبات خارجيه', 'طلب خارجي', 'توصيل', 'بوفيه ل', 'ماده', 'وليمه']],
    ['tour', ['tour', 'show me around', 'guide me', 'جوله', 'خذني', 'دلني على الموقع']],
    ['find', ['section', 'page', 'find', 'go to', 'navigate', 'menu', 'قسم', 'صفحه', 'ابحث', 'دلني', 'اروح', 'وديني', 'قائمه']]
  ];
  var match = function (text) { var n = norm(text); if (!n) return null; for (var i = 0; i < INTENTS.length; i++) { var ks = INTENTS[i][1]; for (var j = 0; j < ks.length; j++) { if (n.indexOf(norm(ks[j])) !== -1) return INTENTS[i][0]; } } return 'fallback'; };

  /* ---- responses: text + action buttons (internal routes rendered by the build; Zimam's official site opens in a new tab) ---- */
  var nav = function (keys) { return keys.map(function (k) { return { key: k, label: T.nav[k], href: L[k], ext: k === 'zimam' || k === 'wa' }; }); };
  var RESP = {
    greeting: function () { return { text: T.r.greeting, actions: nav(['about', 'rooms', 'contact']) }; },
    about: function () { return { text: T.r.about, actions: nav(['about', 'rooms', 'gallery', 'location']) }; },
    services: function () { return { text: T.r.services, actions: nav(['rooms', 'dining', 'meetings', 'catering', 'facilities', 'gallery']) }; },
    meetings: function () { return { text: T.r.meetings, actions: nav(['meetings', 'catering']) }; },
    catering: function () { return { text: T.r.catering, actions: nav(['catering', 'dining']) }; },
    tour: function () { return { text: T.r.tour, actions: nav(['rooms', 'dining', 'meetings', 'catering', 'facilities', 'gallery', 'location', 'contact']) }; },
    transport: function () { return { text: T.r.transport, actions: nav(['zimam']) }; },
    contact: function () { return { text: T.r.contact, actions: nav(['contact', 'wa']) }; },
    faq: function () { return { text: T.r.faq, actions: nav(['guest', 'contact']) }; },
    find: function () { return { text: T.r.find, actions: nav(['about', 'rooms', 'dining', 'meetings', 'catering', 'facilities', 'gallery', 'location', 'guest', 'contact']) }; },
    book: function () { return { text: T.r.book, actions: nav(['book', 'wa']) }; },
    thanks: function () { return { text: T.r.thanks, actions: nav(['rooms', 'contact']) }; },
    bye: function () { return { text: T.r.bye, actions: [] }; },
    fallback: function () { return { text: T.r.fallback, actions: nav(['about', 'rooms', 'dining', 'facilities', 'location', 'contact']) }; }
  };

  /* ---- markup ---- */
  var root = el('div', 'mv'); root.setAttribute('data-marvel', '');
  var fab = el('button', 'mv__fab'); fab.type = 'button'; fab.setAttribute('aria-expanded', 'false'); fab.setAttribute('aria-controls', 'mv-panel'); fab.setAttribute('aria-label', T.open); fab.innerHTML = '<span class="mv__glow" aria-hidden="true"></span><span class="mv__mark">' + ICON.mark + '</span>';
  var bubble = el('div', 'mv__bubble'); bubble.setAttribute('role', 'status'); bubble.innerHTML = '<span>' + T.bubble + '</span><button type="button" class="mv__bubble-x" aria-label="' + T.close + '">' + ICON.close + '</button>';
  var panel = el('section', 'mv__panel'); panel.id = 'mv-panel'; panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', T.name + ' — ' + T.role); panel.hidden = true;
  panel.innerHTML =
    '<span class="mv__wm" aria-hidden="true"></span>' +
    '<header class="mv__head"><span class="mv__avatar" aria-hidden="true">' + ICON.mark + '</span><div class="mv__who"><b>' + T.name + '</b><span>' + T.role + '</span></div>' +
    '<div class="mv__tools"><button type="button" class="mv__tool mv__speak" aria-label="' + T.speak + '" title="' + T.speak + '" hidden>' + ICON.speak + '</button>' +
    '<button type="button" class="mv__tool mv__sound" aria-pressed="false" aria-label="' + T.sound_off + '" title="' + T.sound + '">' + ICON.bellOff + '</button>' +
    '<button type="button" class="mv__tool mv__close" aria-label="' + T.close + '">' + ICON.close + '</button></div></header>' +
    '<div class="mv__log" aria-live="polite" aria-relevant="additions"></div>' +
    '<div class="mv__quick" role="group" aria-label="' + T.name + '"></div>' +
    '<form class="mv__ask" autocomplete="off"><label class="sr-only" for="mv-q">' + T.input_ph + '</label><input id="mv-q" type="text" maxlength="160" placeholder="' + T.input_ph + '"><button type="submit" class="mv__send" aria-label="' + T.send + '">' + ICON.send + '</button></form>';
  var scrim = el('button', 'mv__scrim'); scrim.type = 'button'; scrim.setAttribute('aria-label', T.backdrop || T.close); scrim.tabIndex = -1;
  var handle = el('span', 'mv__handle'); handle.setAttribute('aria-hidden', 'true'); panel.insertBefore(handle, panel.firstChild);
  root.appendChild(scrim); root.appendChild(bubble); root.appendChild(panel); root.appendChild(fab); body.appendChild(root);
  var log = panel.querySelector('.mv__log'), quick = panel.querySelector('.mv__quick'), ask = panel.querySelector('.mv__ask'), input = panel.querySelector('#mv-q');
  var speakBtn = panel.querySelector('.mv__speak'), soundBtn = panel.querySelector('.mv__sound'), closeBtn = panel.querySelector('.mv__close');
  Object.keys(T.quick).forEach(function (k) { var b = el('button', 'mv__chip', T.quick[k]); b.type = 'button'; b.dataset.intent = k; quick.appendChild(b); });

  /* ---- sound (off by default; a 2-note WebAudio chime, created only after a gesture) ---- */
  var soundOn = store.get('mv-sound') === '1', actx = null;
  var setSound = function (on) { soundOn = on; store.set('mv-sound', on ? '1' : '0'); soundBtn.setAttribute('aria-pressed', on ? 'true' : 'false'); soundBtn.setAttribute('aria-label', on ? T.sound_on : T.sound_off); soundBtn.innerHTML = on ? ICON.bell : ICON.bellOff; };
  var chime = function (kind) {
    if (!soundOn) return; try { var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return; actx = actx || new AC(); if (actx.state === 'suspended') actx.resume();
      var t0 = actx.currentTime, notes = kind === 'open' ? [660, 880] : [880, 1100];
      notes.forEach(function (f, i) { var o = actx.createOscillator(), g = actx.createGain(); o.type = 'sine'; o.frequency.value = f; g.gain.setValueAtTime(0.0001, t0 + i * .11); g.gain.exponentialRampToValueAtTime(.05, t0 + i * .11 + .02); g.gain.exponentialRampToValueAtTime(.0001, t0 + i * .11 + .16); o.connect(g); g.connect(actx.destination); o.start(t0 + i * .11); o.stop(t0 + i * .11 + .18); });
    } catch (e) {}
  };
  setSound(soundOn);
  soundBtn.addEventListener('click', function () { setSound(!soundOn); if (soundOn) chime('open'); });

  /* ---- voice (Web Speech API; play/stop; never automatic; cancelled on new speech and on close) ---- */
  var synth = window.speechSynthesis, speaking = false;
  var pickVoice = function () { if (!synth) return null; var vs = synth.getVoices() || [], pref = lang === 'ar' ? /^ar/i : /^en/i; var v = vs.filter(function (x) { return pref.test(x.lang); }); return v.find(function (x) { return x.default; }) || v[0] || null; };
  var setSpeak = function (on) { speaking = on; speakBtn.classList.toggle('is-on', on); speakBtn.setAttribute('aria-label', on ? T.stop : T.speak); speakBtn.title = on ? T.stop : T.speak; speakBtn.innerHTML = on ? ICON.stop : ICON.speak; };
  var stopSpeech = function () { if (synth && (synth.speaking || synth.pending)) synth.cancel(); setSpeak(false); };
  if (synth && window.SpeechSynthesisUtterance) {
    speakBtn.hidden = false;
    speakBtn.addEventListener('click', function () {
      if (speaking) { stopSpeech(); return; }
      stopSpeech(); var u = new SpeechSynthesisUtterance(T.voice); u.lang = lang === 'ar' ? 'ar-SA' : 'en-US'; var v = pickVoice(); if (v) u.voice = v; u.rate = .95; u.pitch = 1.02;
      u.onend = u.onerror = function () { setSpeak(false); }; setSpeak(true); synth.speak(u);
    });
    if (typeof synth.onvoiceschanged !== 'undefined') synth.onvoiceschanged = function () {};
  }

  /* ---- message queue: typing dots → progressive reveal → actions; a new item or a close finishes the current one at once ---- */
  var queue = [], busy = false, timers = [], cancelReveal = null;
  var clearTimers = function () { timers.forEach(clearTimeout); timers = []; };
  var later = function (fn, ms) { var id = setTimeout(fn, ms); timers.push(id); return id; };
  var scrollLog = function () { log.scrollTop = log.scrollHeight; };
  var addUser = function (text) { var m = el('div', 'mv__msg mv__msg--user'); m.innerHTML = '<span class="sr-only">' + T.you + ': </span>'; m.appendChild(el('p', '', text)); log.appendChild(m); scrollLog(); };
  var actionsEl = function (actions, extra) {
    if (!(actions && actions.length) && !extra) return null;
    var wrap = el('div', 'mv__actions'); (actions || []).forEach(function (a) {
      var b = el('a', 'mv__btn' + (a.ext ? ' mv__btn--ext' : ''), a.label); b.href = a.href; if (a.ext) { b.target = '_blank'; b.rel = 'noopener noreferrer'; b.insertAdjacentHTML('beforeend', ' ' + ICON.ext); }
      wrap.appendChild(b);
    }); if (extra) wrap.appendChild(extra); return wrap;
  };
  var reveal = function (p, text, done) {   /* progressive text: word by word (reduced motion / finish(): all at once) */
    var words = text.split(/(\s+)/), i = 0, id = 0, finished = false, n = Math.ceil(words.length / 2), step = Math.max(14, Math.min(34, 1200 / n));   /* whole reveal ≤ ~1.2 s */
    var finish = function () { if (finished) return; finished = true; clearInterval(id); p.textContent = text; cancelReveal = null; done(); };
    if (reduce) { finish(); return; }
    id = setInterval(function () { i += 2; p.textContent = words.slice(0, i).join(''); scrollLog(); if (i >= words.length) finish(); }, step);
    cancelReveal = finish;
  };
  var next = function () {
    if (busy || !queue.length) return; busy = true; var item = queue.shift();
    var typing = el('div', 'mv__typing'); typing.setAttribute('aria-label', T.typing); typing.innerHTML = '<i></i><i></i><i></i>'; log.appendChild(typing); scrollLog();
    var wait = reduce ? 240 : Math.min(1400, 520 + Math.min(item.text.length, 260) * 2.2);
    later(function () {
      typing.remove(); var m = el('div', 'mv__msg'); var p = el('p'); m.appendChild(p); log.appendChild(m); scrollLog(); chime('msg');
      requestAnimationFrame(function () { m.classList.add('is-in'); });
      reveal(p, item.text, function () {
        var a = actionsEl(item.actions, item.extra); if (a) { m.appendChild(a); requestAnimationFrame(function () { a.classList.add('is-in'); }); scrollLog(); }
        busy = false; if (item.after) item.after(); next();
      });
    }, wait);
  };
  var say = function (item) { if (cancelReveal) cancelReveal(); queue.push(item); next(); };
  var respond = function (intent) { var r = (RESP[intent] || RESP.fallback)(); say(r); };

  /* ---- optional name (session only) + personalised greeting ---- */
  var name = store.get('mv-name'), introduced = false;
  var namePrompt = function () {
    var f = el('form', 'mv__name'); f.innerHTML = '<label for="mv-name">' + T.name_prompt + '</label><div class="mv__name-row"><input id="mv-name" type="text" maxlength="30" placeholder="' + T.name_ph + '" autocomplete="given-name"><button type="submit" class="mv__btn">' + T.name_btn + '</button><button type="button" class="mv__btn mv__btn--ghost" data-skip>' + T.name_skip + '</button></div>';
    f.addEventListener('submit', function (e) { e.preventDefault(); var v = f.querySelector('input').value.trim().replace(/[<>]/g, '').slice(0, 30); f.remove(); if (v) { name = v; store.set('mv-name', v); addUser(v); say({ text: T.greet_named.replace('{name}', v), actions: nav(['about', 'rooms', 'contact']) }); } else { respond('find'); } });
    f.querySelector('[data-skip]').addEventListener('click', function () { f.remove(); });
    return f;
  };
  var introduce = function () {
    if (introduced) return; introduced = true;
    if (name) say({ text: T.greet_named.replace('{name}', name), actions: nav(['about', 'rooms', 'contact']) });
    else say({ text: T.intro, actions: [], extra: namePrompt() });
  };

  /* ---- mobile: body scroll lock (keeps iOS from scrolling the page to its end when a field inside the fixed sheet is focused) + keyboard-aware sheet ---- */
  var coarse = !(window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches), small = function () { return window.innerWidth <= 800; };
  var lockY = 0, locked = false;
  var lock = function () { if (locked || !small()) return; locked = true; lockY = window.pageYOffset || 0; body.classList.add('mv-open'); body.style.position = 'fixed'; body.style.top = (-lockY) + 'px'; body.style.left = '0'; body.style.right = '0'; body.style.width = '100%'; };
  var unlock = function () { if (!locked) return; locked = false; body.classList.remove('mv-open'); body.style.position = ''; body.style.top = ''; body.style.left = ''; body.style.right = ''; body.style.width = ''; window.scrollTo(0, lockY); };
  var vv = window.visualViewport;
  var onVV = function () { if (!isOpen || !small() || !vv) return; var kb = Math.max(0, window.innerHeight - vv.height - vv.offsetTop); root.style.setProperty('--mv-kb', kb + 'px'); };
  if (vv) { vv.addEventListener('resize', onVV); vv.addEventListener('scroll', onVV); }

  /* ---- open / close ---- */
  var lastFocus = null, isOpen = false, bubbleTimer = 0;
  var open = function () {
    if (isOpen) return; isOpen = true; lastFocus = d.activeElement; hideBubble(); panel.hidden = false; root.classList.add('is-open'); fab.setAttribute('aria-expanded', 'true');
    lock(); onVV(); requestAnimationFrame(function () { panel.classList.add('is-open'); }); chime('open'); introduce();
    later(function () { var f = coarse ? closeBtn : (panel.querySelector('.mv__name input') || quick.querySelector('button') || closeBtn); f.focus({ preventScroll: true }); }, reduce ? 50 : 260);   /* no keyboard pops up on touch devices */
  };
  var close = function () {
    if (!isOpen) return; isOpen = false; clearTimers(); if (cancelReveal) cancelReveal(); queue = []; busy = false; var t = log.querySelector('.mv__typing'); if (t) t.remove(); stopSpeech();
    panel.classList.remove('is-open'); root.classList.remove('is-open'); fab.setAttribute('aria-expanded', 'false'); root.style.removeProperty('--mv-kb'); if (d.activeElement && panel.contains(d.activeElement)) d.activeElement.blur(); unlock();
    setTimeout(function () { if (!isOpen) panel.hidden = true; }, reduce ? 0 : 360); fab.focus({ preventScroll: true });
  };
  var hideBubble = function () { clearTimeout(bubbleTimer); bubble.classList.remove('is-in'); root.classList.remove('has-bubble'); };
  fab.addEventListener('click', function () { isOpen ? close() : open(); });
  Array.prototype.slice.call(d.querySelectorAll('[data-marvel-open]')).forEach(function (b) { b.addEventListener('click', function () { var intent = b.dataset.marvelOpen; open(); if (intent && RESP[intent]) { if (introduced && queue.length === 0 && !busy) respond(intent); else later(function () { respond(intent); }, 0); } }); });
  closeBtn.addEventListener('click', close); scrim.addEventListener('click', close);
  var sy0 = null; panel.addEventListener('touchstart', function (e) { sy0 = (e.target.closest('.mv__head') || e.target === handle) ? e.touches[0].clientY : null; }, { passive: true }); panel.addEventListener('touchend', function (e) { if (sy0 !== null && e.changedTouches[0].clientY - sy0 > 60) close(); sy0 = null; }, { passive: true });   /* swipe the header down to close */
  d.addEventListener('keydown', function (e) { if (e.key === 'Escape' && isOpen) { e.preventDefault(); close(); } });
  bubble.querySelector('.mv__bubble-x').addEventListener('click', function () { hideBubble(); store.set('mv-bubble', '1'); });
  bubble.addEventListener('click', function (e) { if (!e.target.closest('.mv__bubble-x')) { open(); } });
  if (store.get('mv-bubble') !== '1' && !reduce) { bubbleTimer = setTimeout(function () { if (!isOpen) { root.classList.add('has-bubble'); bubble.classList.add('is-in'); bubbleTimer = setTimeout(hideBubble, 9000); } }, 4000); }

  /* ---- quick actions + free text ---- */
  quick.addEventListener('click', function (e) { var b = e.target.closest('.mv__chip'); if (!b) return; addUser(b.textContent); respond(b.dataset.intent); });
  log.addEventListener('click', function (e) { var a = e.target.closest('a.mv__btn'); if (a && a.target !== '_blank') { unlock(); window.scrollTo(0, 0); } });
  ask.addEventListener('submit', function (e) { e.preventDefault(); var v = input.value.trim(); if (!v) return; input.value = ''; addUser(v); respond(match(v) || 'fallback'); });
  d.addEventListener('visibilitychange', function () { if (d.hidden) stopSpeech(); });
  window.addEventListener('pagehide', stopSpeech);
  html.classList.add('has-marvel');
})();
